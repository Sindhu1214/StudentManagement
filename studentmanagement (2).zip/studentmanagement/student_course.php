<?php

 session_start();
 if(!isset($_SESSION['username']))
 {
  header("location:login.php");
 }
 elseif($_SESSION['usertype']=='admin')
 {
    header("location:login.php");
 }
?>







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="adminhome.css">
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<style>
    h1{
        font-size: 20;
        color: black;
    }
  
a{
        font-size: 20px;
        color: black;
       
        
    }
   
    .header
{

    background-color:#317397;
    line-height: 70px;
    padding-left: 30px;
}
li{
    font-size: 20px;
    color:black;
    display: inline;
}
body{
           
           background-image: url('b2.jpg');
           background-repeat: no-repeat;
           background-attachment: fixed;
           background-size: 100% 100%;
}
ul
{
    background-color: #317397;
}
th{
    font-size: 30px;
}
.span a
{
    color: black;
    font-size: 20px;
}
 </style>

</head>
<body>
    <?php
    include "student_sidebar.php";
    ?>
  
<center>
    <h1>Student Courses</h1><br><br>
    <span class="span">
    <span>
  <a href="https://www.coursera.org/courses?query=artificial%20intelligence" class="btn btn-primary"> Artificial Intelligence</a>
  </span>&nbsp;&nbsp;&nbsp;
  <span>
  <a href="https://youtu.be/O3NU5dLDU2Q?si=l0byYdaLtSAKuA-g" class="btn btn-primary">Automata Theory And Complier Design</a>
  </span><br><br><br>
 
  <span>
  <a href="https://www.scaler.com/topics/course/dbms/" class="btn btn-primary"> Database Management System</a>
  </span>&nbsp;&nbsp;&nbsp;
  <span>
  <a href="https://youtu.be/i6JGg1jFzyM?si=-FEOpCu1nbx9HbJB" class="btn btn-primary"> Database Management System Lab</a>
  </span><br><br><br>
  <span>
  <a href="https://youtu.be/VwN91x5i25g?si=-aykhQtmdaF3pArx" class="btn btn-primary"> Computer  Network</a>
  </span>&nbsp;&nbsp;&nbsp;
  <span>
  <a href="https://youtu.be/Os-NTf1IjNg?si=0axc1prFDDXcAQmV" class="btn btn-primary"> Computer Network Lab </a>
  </span><br><br><br>
  <span>
  <a href="https://youtu.be/1vf8ZvADxfY?si=wjNBfa2tN-SmjpsM" class="btn btn-primary"> Research Methadology And intellectul Property</a>
  </span>&nbsp;&nbsp;&nbsp;
  <span>
  <a href="https://youtu.be/zuSFs85kuJs?si=4RhUrxl-xNk-W65m" class="btn btn-primary"> Environmental Studies</a>
  </span><br><br><br>
  <span>
  <a href="https://youtu.be/t7x7c-x90FU?si=w_lScty_ZHeMdmP7" class="btn btn-primary"> Angular JS And Node JS</a>
  </span>&nbsp;&nbsp;&nbsp;
 
  
  
    
             
            
                
    </span>         
       





   
</center>




</body>
</html>


        
       

    

</center>


</div>

</body>
</html>

  



