<?php

 session_start();
 error_reporting(0);
 if(!isset($_SESSION['username']))
 {
  header("location:login.php");
 }
 elseif($_SESSION['usertype']=='student')
 {
    header("location:login.php");
 }
 $host="localhost";
 $user="root";
 $password="";
 $db="schoolproject";
 
 $data=mysqli_connect($host,$user,$password,$db);
 if($_GET['teacher_id'])
 {

 
 $t_id=$_GET['teacher_id'];
$sql="SELECT * FROM teacher WHERE id='$t_id'";
$result=mysqli_query($data,$sql);
$info=$result->fetch_assoc();
 }
 if(isset($_POST['update']))
 {
 $id=$_POST['id'];  
 $t_name=$_POST['name'];    
 $t_description=$_POST['description']; 
 $file=$_FILES['image']['name'];
 $dst="./image/".$file;
 $dst_db="image/".$file;
 move_uploaded_file($_FILES['image']['tmp_name'],$dst);
 if($file)
 {
    $sql2="UPDATE teacher SET name='$t_name',description='$t_description',image='$dst_db' WHERE id='$id'";
 }
 else
 {
    $sql2="UPDATE teacher SET name='$t_name',description='$t_description', WHERE id='$id'";
 }
 $result2=mysqli_query($data,$sql2);
 if($result2)

 {
    header('location:view_teacher.php');
 }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="adminhome.css">
    <style type="text/css">
        label{
            display: inline-block;
            text-align: center;
            width: 100px;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        .div_deg
        {
            background-color: skyblue;
            width: 400px;
            padding-top: 70px;
            padding-bottom: 70px;
        }
</style>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</head>
<body>
<?php

include 'admin_sidebar.php';

?>
 
  




<div class="content">
<center>
<h1>
    Update Teacher Data
 </h1>
<div class="div_deg">
<form class="form_deg" action="#" method="POST" enctype="multipart/form-data">
    <input type="text" name="id" value="<?php echo "{$info['id']}"?>" hidden>
    <div>
       <label for="">Teacher Name</label>
       <input type="text" name="name" value="<?php echo "{$info['name']}";?>">

    </div>
    <div>
       <label for="">About Teacher</label>
      <textarea name="description" rows="4">
      <?php echo "{$info['description']}";?>
      </textarea>

    </div>
   
    <div>
       <label for="">Teacher Old Image</label>
      <img width='100px' height='100px' src="<?php echo "{$info['image']}";?> ">

    </div>
    <div>
       <label for=""> Choose Teacher New Image</label>
       <input type="file" name="image">

    </div>
    <div>
           
           <input type="submit" class="btn btn-primary" name="update" value="Update">
       </div>
</form>


</div>

</body>
</html>
