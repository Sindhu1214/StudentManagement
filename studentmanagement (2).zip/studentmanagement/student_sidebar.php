<style>
a{
        font-size: 20;
        color: white;
    }
   
    .header
{

    background-color:#317397;
    line-height: 70px;
    padding-left: 30px;
}
a{
    font-size: 20;
    color:black;
}
body{
           
           background-image: url('b2.jpg');
           background-repeat: no-repeat;
           background-attachment: fixed;
           background-size: 100% 100%;
}
ul
{
    background-color: #317397;
}
    </style>
<header class="header">

    <a href="student_course.php">Student Cources</a>

    <div class="logout">

    <a href="logout.php" class="btn btn-primary">Logout</a>

    </div>

</header>

<aside>

<ul >
<li>
    <a href="student_profile.php">My Profile</a><br><br>
</li>
<li>
    <a href="student_course.php">My Courses</a>
</li>





</ul>

</aside>
