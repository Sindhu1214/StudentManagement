<?php

 session_start();

 $host="localhost";

 $user="root";
 
 $password="";
 
 $db="schoolproject";
 
 $data=mysqli_connect($host,$user,$password,$db);
 if(isset($_POST['contacts']))
 {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $message=$_POST['message'];
   
   

    

   


    

    $sql="INSERT INTO contact(name,email,message) VALUES ('$name','$email','$message')";
    $result=mysqli_query($data,$sql);
    if($result)
    {
        echo "<script>
        alert('Thank you')       </script>";
    }
    else{
        echo "Upload Fail";
    }
}

 
 
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="adminhome.css">
    <style type="text/css">
        body{
            background-image: url('cback.avif');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
}
        
        label{
            display: inline-block;
            text-align: center;
            width: 100px;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        .div_deg
        {
            background-color:silver;
            width: 700px;
            padding-top: 100px;
            padding-bottom: 100px;
        }



        </style>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</head>
<body>
    
  



   

<div class="content">
    <center>

<h1>
    Contact Us
</h1>
<div class="div_deg">
    <form action="#" method="POST">
        <div>

            <label for="">Name</label>
            <input type="text" name="name">
        </div>
        <div>
            <label for="">Email</label>
            <input type="email" name="email">
        </div>
       
        
        <div>
        <label for="">Message</label>
      <textarea name="message" rows="4">
     
      </textarea>
        </div>
        <div>
           
            <input type="submit" class="btn btn-primary" name="contacts" value="Send"><br><br>
            <a href="index.php" class="btn btn-primary">Home</a>
        </div>
    </form>
</div>
    </center>

</div>

</body>
</html>
