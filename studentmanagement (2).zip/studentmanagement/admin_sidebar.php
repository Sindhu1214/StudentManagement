<style>
    .header
{

    background-color:#317397;
    line-height: 70px;
    padding-left: 30px;
}
a{
    font-size: 20;
    color:white;
}
body{
           
           background-image: url('b2.jpg');
           background-repeat: no-repeat;
           background-attachment: fixed;
           background-size: 100% 100%;
}
ul
{
    background-color: #317397;
}

    </style>
<header class="header">

    <a href="">Admin Dashboard</a>

    <div class="logout">

    <a href="logout.php" class="btn btn-primary">Logout</a>

    </div>

</header>
<aside>

<ul >

<li>
    <a href="admission.php">Admission</a>
</li>

<li>
    <a href="add_student1.php">Add Student</a>
</li>

<li>
    <a href="view_student.php">View Student</a>
</li>
<li>
    <a href="add_teacher.php">Add Teacher</a>
</li>

<li>
    <a href="view_teacher.php">View Teacher</a>
</li>

<li>
    <a href="add_course.php">Add Courses</a>
</li>

<li>
    <a href="view_course.php">View Cources</a>
</li>
<li>
    <a href="view_contact.php">Contact Us</a>
</li>

</ul>

</aside>