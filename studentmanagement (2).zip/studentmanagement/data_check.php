<?php

session_start();
$host="localhost";

$user="root";

$password="";

$db="schoolproject";

$data=mysqli_connect($host,$user,$password,$db);
if($data===false)
{
  die("connection error");
}
if(isset($_POST['apply']))
{
  $dname=$_POST['name'];
  $demail=$_POST['email'];
  $dphone=$_POST['phone'];
  $dmessage=$_POST['message'];

  $sql="INSERT INTO admission(name,email,phone,message) VALUES('$dname','$demail','$dphone','$dmessage')";
  $result=mysqli_query($data,$sql);
  
  if($result)
  {
    $_SESSION['message']="your application sent successful";
    header("location:index.php");
  }
  else{
    echo "Apply Failed";
  }
}
